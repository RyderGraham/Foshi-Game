import random
import sys
import os.path

dagger = False
currentRoom = 1
gameOver = False
playerLP = 7
OpieLP = 4
healthScroll = False
scrollUses = 0

introTXT = '0_intro.txt'
libraryTXT = '1_library.txt'
workshopTXT = '2_workshop.txt'
emptyRoomTXT = '3_empty.txt'
wellRoomTXT = '4_well.txt'
foshiTXT = '5_foshi.txt'
riddleTXT = '6_riddle.txt'

#-------------------------------------

def read_text(file_path):
    if os.path.isfile(file_path):
        with open(file_path, 'r') as file:
            return file.read()
    else:
        print(f'The file {file_path} does not exist')


introTXT = read_text(introTXT)
libraryTXT = read_text(libraryTXT)
workshopTXT = read_text(workshopTXT)
emptyRoomTXT = read_text(emptyRoomTXT)
wellRoomTXT = read_text(wellRoomTXT)
foshiTXT = read_text(foshiTXT)
riddleTXT = read_text(riddleTXT)

#-------------------------------------

def diceRoll(numSides, function, success):
    result = ""
    roll = random.randint(1, numSides)

    if function == 'attack':
        if roll == 1:
            result = 'Critical fail'
        elif roll == 20:
            result = 'Critical hit'
        elif roll >= success:
            result = 'Hit'
        else:
            result = 'Miss'
        if dagger == True:
            if roll == 1:
                result = 'Critical fail'

    if function == 'check':
        if roll >= success:
            result = 'Success'
        else:
            result = 'Fail'

    if function == "light":
        if roll >=success:
            result = 'Success'
            bonusRoom()
        else:
            result = 'Fail'
            
    if function == 'foshi':
        if roll >= success:
            result='intelligence'
        if roll < success:
            result='confused'
            
    if function == 'foshiAttack':
        if roll > 0 :
            result = 'Miss'

    if function == 'noLight':
        if roll == 1:
            result = 'Critical fail'
        elif roll == 20:
            result = 'Critical hit!'
        elif roll >= success:
            result = 'Hit'
        for _ in range(2):
            roll = random.randint(1, numSides)
            result.append(roll)

            return min(result), result
    return roll, result

#-----------------------------------------

def beginGame():
    print(introTXT)
    gameOver = False
    while not gameOver:
        print("1 begin game, 2 leave the building")
        userInput = int(input())
        if userInput == 1:
            print("You\'ve decided to continue.")
            print('PlayerLP:', playerLP)
            library()
        elif userInput == 2:
            print("You leave the building.")
            gameOver = True
        else:
            print("Invalid input try again.")

#--------------------------------------------

def library():
    print(libraryTXT)
    print("1 go through the trap door, 2 go to the room west, 3 go to the room to the north, 4 you decide to search the room")
    global playerLP, healthScroll, scrollUses, gameOver

    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")

        userInput = int(input())

        if userInput == 1 :
            print("You enter down the trap")
            bonusRoomDecide()
            break  # Exit the loop after bonusRoomDecide() execution
        elif userInput == 2 :
            print("You enter into the Workshop")
            workshopRoom()
            break  # Exit the loop after workshopRoom() execution
        elif userInput == 3 :
            print("You enter into an Empty Room")
            emptyRoom()
            break  # Exit the loop after emptyRoom() execution
        elif userInput == 4 : 
            print("You decide to search the Room")
            diceRollLibrary = diceRoll(20, "check", 12)
            roll, result = diceRollLibrary
            if result == 'Success':
                print("you found the scroll!! It\'s now in your inventory.")
                scrollRoll = random.randint(1, 6)
                scrollUses = scrollRoll
                print('Scroll Uses left:', scrollUses)
                healthScroll = True
                libraryNoSearch()
            else:
                print("You didn\'t find the scroll, choose a different move.")
                libraryNoSearch()
            break
        else:
            print("Invalid input. Please try again.")

        if gameOver: 
            break


#------------------------------------------------------------------------------

def libraryNoSearch():
    global playerLP, healthScroll, scrollUses
    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
                
        print("1 go through the trap door, 2 go to the room west, 3 go to the room to the north")
        userInput = int(input())
        
        if userInput == 1 :
            print("You enter down the trap")
            bonusRoomDecide()
        elif userInput == 2 :
            print("You enter into the Workshop")
            workshopRoom()
        elif userInput == 3 :
            print("You enter into an Empty Room")
            emptyRoom()
        else:
            print("Invalid input. Please try again.")

#----------------------------------------------------------

def wellRoom(attempts=3):
    global gameOver
    print(wellRoomTXT)
    
    print(foshiTXT)
    
    gameOver = False
    roll, result = diceRoll(20, 'foshi', 18)
    print(result)
    if result == 'intelligence':
        print("You realize foshi is just an allusion, now you just have to solve the riddle")
    if result == 'confused':
        print('It begins to feel like Foshi is merging with you')
        print('1 attack Foshi, 2 Try to solve Foshi\'s riddle')
        userInput1 = int(input())
        if userInput1 == 1 :
            roll, result = diceRoll(20, 'foshiAttack', 0)
            if result == 'Miss':
                print("Your attack missed!")
                
    print(riddleTXT)        
    while not gameOver:
        for attempt in range(1, attempts + 1):  
            userInput2 = input().lower()
            if userInput2 == "tomorrow":
                print("It\'s a match, You win!!")
                gameOver = True
                sys.exit()
            else:
                remaining_attempts = attempts - attempt
                print(f"Incorrect answer. You have {remaining_attempts} attempt(s) remaining.")
                if remaining_attempts == 0 :
                    print("You've used all your attempts. Game Over.")
                    gameOver = True
                    sys.exit() 
    gameOver = True      
    print("You've used all your attempts. Game Over.")
    return False

#------------------------------------------------------

def emptyRoom():
    global playerLP, healthScroll, scrollUses, gameOver

    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
                
        print(emptyRoomTXT)
        print("1 go back to the library, 2 go to the room west, 3 search the room")
        userInput = int(input())
        if userInput == 1:
            print("You've decided to go back to the library")
            library()
        elif userInput == 2:
            print("You've decided to go to the room to the west")
            trapRoom()
        elif userInput == 3:
            print("You've decided to search the room")
            searchEmptyRoom = diceRoll(20, 'check', 12)
            roll, result = searchEmptyRoom
            if result == 'success':
                print('You found a trap door and avoided it!')
                emptyRoomNoTrap()
            elif result == 'fail':
                print("You didn't find anything")
                emptyRoomTrap()
        else:
            print("Invalid input. Please try again.")

#----------------------------------------------------------------
            
def emptyRoomNoTrap():
    print('1 go back to the library, 2 go to the room west')
    userInput = int(input())
    if userInput == 1:
        print('You\'ve decided to go back to the Library')
        libraryNoSearch()
    if userInput == 2:
        print('You decide to go to the room to the west.')
        wellRoom()
    else:
        print('Invalid Input,Try again')
        emptyRoomNoTrap()
        
#----------------------------------------------------------
    
def emptyRoomTrap():
    global playerLP, healthScroll, scrollUses
    
    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
    print('1 go back to the library, 2 go to the room west')
    userInput = int(input())
    if userInput == 1:
        print('You\'ve decided to go back to the library.')
        libraryNoSearch()
    elif userInput == 2:
        print('You\'ve decided to go to the room to the west.')
        print('As you start walking towards the door you fall into a trap')
        trapRoom()
    else:
        print('Invalid input, try again.')
        
#--------------------------------------------------------------------
    
def trapRoom():
    fallDamage = random.randint(1, 6)
    print("You've fallen into a trap door! You lose ",fallDamage,"LP!")
    global playerLP
    while playerLP > 0:
        playerLP -= 6 
        if playerLP > 0:
            print('Player LP', playerLP)
            print('Press 1 to climb out of the trap room.')
            userInput = int(input())
            if userInput == 1:
                emptyRoomNoTrap()
            else:
                print('Incorrect Input, Try again.')
        if playerLP <= 0:
            print("Game Over, You died!")
            sys.exit()
        else:("Not understood, try again.")
    
#---------------------------------------------------------------------
    
def workshopRoom():
    global playerLP, scrollUses, healthScroll, dagger, gameOver
    
    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
        
        print(workshopTXT)
        print("1 you can move onto the next room, 2 you can go back to the library, 3 you can search the room")
        userInput = int(input())
        
        if userInput == 1:
            print("You've decided to move to the next room")
            wellRoom()
        elif userInput == 2:
            print("You've decided to go back to the library")
            libraryNoSearch()
        elif userInput == 3:
            print("You've decided to search the room")
            diceRollWorkshop = diceRoll(20, "check", 12)
            roll, result = diceRollWorkshop
            print(roll, result)
            if result == "Success":
                dagger = True
                if dagger:
                    print("You've found a dagger!! ")
                else:
                    print("You found nothing.")
                workshopRoomNoSearch()
        else:
            print('Incorrect input, try again.')

#------------------------------------------------------------

def workshopRoomNoSearch():
    global playerLP, scrollUses, healthScroll, gameOver
    
    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
        
        print("1 you can move onto the next room, 2 you can go back to the library")
        userInput = int(input())
        
        if userInput == 1:
            print("You've decided to move to the next room")
            wellRoom()
            break
        elif userInput == 2:
            print("You've decided to go back to the library")
            library()
            break  
        else:
            print('Incorrect input, Try Again.')

        
#---------------------------------------------------------------

def bonusRoomDecide():
    global playerLP, healthScroll, scrollUses, gameOver
    
    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
                
        print("You\'ve decided to go down the stairs, and enter a dark room.")
        print("1 search the room for a lightswitch, 2 turn around and go back up the stairs")
        userInput = int(input())
        if userInput == 1:
            print("You\'ve decided to search the room")
            diceRollDecide = diceRoll(20, "light", 10)
            roll, result = diceRollDecide
            if result == 'Success':
                bonusRoom()
                break  # Exit the loop after bonusRoom() execution
            elif result == 'Fail':
                bonusRoomNoLight()
                break  # Exit the loop after bonusRoomNoLight() execution
            else:
                print("Something isn't right, try again.")
        elif userInput == 2:
            print("You decide to go back upstairs.")
            libraryNoSearch()
            break  # Exit the loop after libraryNoSearch() execution
        else:
            print("Invalid input, try again.")

        
#--------------------------------------------------

def bonusRoom():
    print("You found the light switch, and can now see in the room and it\'s layed out as a bedroom, with a bed in the back left corner and a closet on the back right.")
    print("----------------------------")
    print("As you continue to look around a large monster named Opie, and he starts a battle with you.")
    global playerLP, OpieLP
    while playerLP > 0 and OpieLP > 0:
        attack = diceRoll(20, 'attack', 12)
        roll, result = attack
        if result == 'Critical fail':
            print('Player misses with a critical fail')
        elif result == 'Critical hit':
            OpieLP -= 4*2
            print('Player lands a critical hit!')
        elif result == 'Hit':
            print('Player hits the monster!')
            OpieLP -= 2
            if dagger:
                OpieLP-= 2*2 
            else: OpieLP-=2
        else:
            print('Player misses')
        print("Monster's LP:", OpieLP)

        if OpieLP <= 0: 
            print("Player wins!")
            bonusRoomSearch()
            break
        attack = diceRoll(20, 'attack', 12)
        roll, result = attack
        if result == 'Critical fail':
            print('Monster misses with a critical fail')
        elif result == 'Critical hit':
            playerLP -= 4
            print('Monster lands a critical hit!')
        elif result == 'Hit':
            print('Monster hits the player!')
            playerLP -= 2
        else:
            print('Monster misses')
        print("Player's LP:", playerLP)

        if playerLP <= 0: 
            print("Monster wins!")
            break  
        
#----------------------------------------------------------------------

def bonusRoomNoLight():
    print("Although you were unable to find the light switch, you continue to look around.")
    print("----------------------------")
    print("As you continue to look around, a large monster named Opie appears, and he starts a battle with you.")
    global playerLP, OpieLP, dagger

    while playerLP > 0 and OpieLP > 0:
        # Player's turn
        roll, result = diceRoll(20, 'attack', 12)  
        if result == 'Critical Fail':
            print('You miss with a critical fail')
        elif result == 'Critical Hit':
            OpieLP -= 4
            print('You land a critical hit!')
        elif result == 'Hit':
            print('You hit Opie!')
            if dagger:
                OpieLP -= 4  
            else:
                OpieLP -= 2
        else:
            print('You miss')
        print("Opie's LP:", OpieLP)

        if OpieLP <= 0: 
            print("Player wins!")
            bonusRoomSearch()
            

        # Opie's turn
        roll, result = diceRoll(20, 'attack', 12)  
        if result == 'Critical Fail':
            print('Opie misses with a critical fail')
        elif result == 'Critical Hit':
            playerLP -= 4
            print('Opie lands a critical hit!')
        elif result == 'Hit':
            print('Opie hits the player!')
            playerLP -= 2
        else:
            print('Opie misses')
        print("Player's LP:", playerLP)

        if playerLP <= 0:  
            print("Opie wins!")
            break
  
#----------------------------------------------------------------
#TODO
def bonusRoomSearch():
    global playerLP, healthScroll, scrollUses, gameOver
    while not gameOver:
        if healthScroll and playerLP < 7:
            print('Player LP:', playerLP, 'Would you like to use the scroll? 1 Yes, 2 No')
            scroll_input = input()
            if scroll_input == '1':
                if scrollUses > 0:
                    health_roll = random.randint(1, 4)
                    playerLP += health_roll
                    playerLP = min(playerLP, 7)
                    scrollUses -= 1
                    print('Player LP:', playerLP)
                else:
                    print('No more scroll uses left!')
            elif scroll_input == '2':
                print("You've decided not to use the scroll.")
            else:
                print("Invalid input, try again.")
        print("Congratulations! You've killed Opie.")
        print("1 go back up the stairs, 2 search the room")
        userInput = int(input())
        if userInput == 1:
            print("You've decided to go back upstairs")
            libraryNoSearch()
        elif userInput == 2:
            print("There is nothing in this room, press 1 to go upstairs")
            userInput2 = int(input())
            if userInput2 == 1:
                print('You go back upstairs.')
                libraryNoSearch()
            else:
                print("Incorrect input, try again.")

# Start the game
beginGame()
